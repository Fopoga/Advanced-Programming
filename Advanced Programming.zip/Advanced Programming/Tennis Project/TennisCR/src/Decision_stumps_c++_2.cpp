#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
double gini_impurity_Cpp(NumericVector left, NumericVector right) {
  
  double p_yes_l = sum(left) / left.size();
  
  double p_yes_r = sum(right) / right.size();
  
  double gini_left = 1.0 - (p_yes_l * p_yes_l + (1.0 - p_yes_l) * (1.0 - p_yes_l));
  
  
  double gini_right = 1.0 - (p_yes_r * p_yes_r + (1.0 - p_yes_r) * (1.0 - p_yes_r));
  
  double total_size = left.size() + right.size();
  double w_gini = (left.size() / total_size) * gini_left + 
    (right.size() / total_size) * gini_right;
  
  return w_gini;
}

// [[Rcpp::export]]
List best_split_Cpp(NumericMatrix X, NumericVector y) {
  
  // We Initialize the Gini Index with value 1.0 (worst possible value)
  double best_gini = 1.0;
  
  // We Initialize the best feature index as -1
  int best_feature = -1;
  
  // We Initialize the best value placeholder
  double best_value = 0;
  
  // We save the number of features and rows in X
  int n_features = X.ncol();
  int n_samples = X.nrow();
  
  // We loop through each feature
  for (int feature = 0; feature < n_features; ++feature) {
    
    
    NumericVector values = unique(X(_, feature));
    
    // We loop through each unique value
    for (double value : values) {
      
      // We Create a left and right subsets based on the current value
      std::vector<double> left, right;
      
      // We reserve space to minimize dynamic resizing
      left.reserve(n_samples);
      right.reserve(n_samples);
      
      for (int i = 0; i < n_samples; ++i) {
        if (X(i, feature) == value) {
          left.push_back(y[i]);
        } else {
          right.push_back(y[i]);
        }
      }
      
      // If one of the subsets it's empty, we skip it
      if (left.empty() || right.empty()) {
        continue;
      }
      
      // we obtain Gini index for the current split
      double gini = gini_impurity_Cpp(wrap(left), wrap(right));
      
      // We update the best split if the current Gini is better (smaller)
      if (gini < best_gini) {
        best_gini = gini;
        best_feature = feature + 1;  // As R uses 1-based indexing, we add 1
        best_value = value;
      }
    }
  }
  
  //We return a list with the final solution
  return List::create(
    _["best_feature"] = best_feature,
    _["best_value"] = best_value,
    _["best_gini"] = best_gini
  );
}


/*** R

# Base input
PT <- num_matrix_from_df(play_tennis)

X <- PT[, 1:4]  
y <- PT[, 5]  

best_split_Cpp(X, y)
*/

/*** R

# Dataset without feature 'Outlook'

X2 <- PT[, 2:4]  
best_split_Cpp(X2, y)

# In this case we have 3 features: Temperature, Humidity, and Wind. 
# The result matches the right solution. 
# Without Outlook, Humidity (feature nº 2) 
# has the lowest Gini taking as reference High (category 0)

*/

/*** R
X3 <- PT[, c(2,4)]  
best_split_Cpp(X3,y)
# In this case we have 2 features: Temperature and Wind. 
# The result matches the right solution. 
# 1, 1, 0.44
*/

/*** R
# In this case, all the feature values are the same, making it impossible to split the data meaningfully.

X4 <- matrix(rep(1, 8), ncol = 1)
y2 <- c(1, 0, 1, 0, 1, 0, 1, 0)

best_split_Cpp(X4, y2)

# The obtained result is the expected. The index has remained in -1 (it was initialized like this)
*/



