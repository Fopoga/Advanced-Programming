#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
double gini_impurity_Cpp(NumericVector left, NumericVector right) {
  
  
  double p_yes_l = sum(left) / left.size();
  
  double p_yes_r = sum(right) / right.size();
  
  double gini_left = 1.0 - (p_yes_l * p_yes_l + (1.0 - p_yes_l) * (1.0 - p_yes_l));
  
  double gini_right = 1.0 - (p_yes_r * p_yes_r + (1.0 - p_yes_r) * (1.0 - p_yes_r));
  
  double total_size = left.size() + right.size();
  double w_gini = (left.size() / total_size) * gini_left + 
    (right.size() / total_size) * gini_right;
  
  return w_gini;
}

// [[Rcpp::export]]
List gini_table_Cpp(NumericMatrix X, NumericVector y) {
  
  double best_gini = 1.0;
  
  int best_feature = -1;
  
  double best_value = 0;
  
  std::vector<int> features;   // Feature index
  std::vector<double> values;  // Feature value (category)
  std::vector<double> ginis;   // Gini index
  
  int n_features = X.ncol();
  
  for (int feature = 0; feature < n_features; ++feature) {
    
    NumericVector values_unique = unique(X(_, feature));
    
    for (double value : values_unique) {
      
      LogicalVector left_indices = X(_, feature) == value;
      LogicalVector right_indices = X(_, feature) != value;
      
      NumericVector left = y[left_indices];
      NumericVector right = y[right_indices];
      
      if (left.size() == 0 || right.size() == 0) {
        continue;
      }
      
      double gini = gini_impurity_Cpp(left, right);
      
      // We save the feature, value, and Gini index in the vectors
      features.push_back(feature + 1);  // As R uses 1-based indexing, we add 1
      values.push_back(value);
      ginis.push_back(gini);
      
      // We update the best split if the current Gini is better (smaller)
      if (gini < best_gini) {
        best_gini = gini;
        best_feature = feature + 1;  // R uses 1-based indexing
        best_value = value;
      }
    }
  }
  
  // We create a dataframe to store all Gini indices, categories, and features
  DataFrame gini_results = DataFrame::create(
    _["Feature"] = features,
    _["Value"] = values,
    _["Gini"] = ginis
  );
  
  return gini_results;
  
}


