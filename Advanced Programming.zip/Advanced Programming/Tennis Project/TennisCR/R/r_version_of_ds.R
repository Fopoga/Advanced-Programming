# You must program this function, first in R, then in C++
gini_impurity_R <- function(left, right) {
  
  # Calculates the proportion of "yes" (1's) in the left subset
  p_yes_l <- sum(left) / length(left)
  
  # Calculates the proportion of "yes" (1's) in the right subset
  p_yes_r <- sum(right) / length(right)
  
  # Calculates the Gini impurity for the left subset
  gini_left <- 1 - (p_yes_l^2 + (1 - p_yes_l)^2)
  
  # Calculates the Gini impurity for the right subset
  gini_right <- 1 - (p_yes_r^2 + (1 - p_yes_r)^2)
  
  # Calculates the weighted Gini impurity
  w_gini <- (length(left) / (length(left) + length(right))) * gini_left + 
    (length(right) / (length(left) + length(right))) * gini_right
  
  return(w_gini)
}

#The function best_split_R requires 2 arguments:
# X: Numeric matrix with the independent variables
# y: Numeric vector (one column) with the response variable
best_split_R <- function(X, y) {
  
  # We initialize the Gini Index with value 1, as is the worst possible value it can take
  best_gini <- 1.0
  
  # We initialize the best feature index as -1. 
  # It has to be different from a natural number, because this numbers refer to our features in the matrix X
  best_feature <- -1
  
  #  We compute the number of features that we have counting the number of columns in X.
  n_features <- ncol(X)
  
  # This loops goes through all the values of 'n_features'. (In this case 4).
  for (feature in 1:n_features) {
    
    # Unique() returns a numeric vector with the corresponding possible values of the feature column.  
    values <- unique(X[, feature])
    
    for (value in values) {
      
      # We save in two different vectors (left and right) a logical vector (Meaning it contains TRUE or FALSE). 
      # In the left vector we have saved as TRUE (ones) when the category that it's been evaluated at the moment matches. 
      # In the right one we save as TRUE (ones) all the remaining categories.
      left_indices <- X[, feature] == value
      right_indices <- X[, feature] != value
      
      left <- y[left_indices]
      right <- y[right_indices]
      
      gini <- gini_impurity_R(left, right)
      
      
      
      if (gini < best_gini) {
        best_gini <- gini # This variable will change when a feature's Gini Index is better (smaller) than the previous ones. 
        best_feature <- feature # Store the best feature index
        best_value <- value # It's a Feature indicator related to the best Gini Index
      }
    }
  }
  
  # Prints a list with the final result
  output <- list(
     
    best_feature = best_feature,
    best_value = best_value,
    best_gini = best_gini
  )
  
  output
}

# X is a numeric matrix with the input predictors
# y is a numeric vector with the response values (the two classes: 0 or 1)
# In order to obtain X and y from the play_tennis dataset, you'll need the 
# num_matrix_from_df function.

fit_decision_stump_R <- function(X, y) {
  best_split_R(X, y) # Call best_split and return the best feature index
}

## 9. 

best_split_R_9 <- function(X, y) {
  
  best_gini <- 1.0
  
  best_feature <- -1
  
  # We initialize the majority class of the right branch
  right_class <- NA
  
  n_features <- ncol(X)
  
  for (feature in 1:n_features) {
    
    values <- unique(X[, feature])
    
    for (value in values) {
      
      left_indices <- X[, feature] == value
      right_indices <- X[, feature] != value
      
      left <- y[left_indices]
      right <- y[right_indices]
      
      gini <- gini_impurity_R(left, right)
      
      if (gini < best_gini) {
        best_gini <- gini
        best_feature <- feature
        best_value <- value
        
        # We determine the majority class in the right branch
        right_class <- names(sort(table(right), decreasing = TRUE))[1]
      }
    }
  }
  output <- list(
    best_feature = best_feature,
    best_value = best_value,
    best_gini = best_gini,
    right_class = right_class
  )
  
  return(output)
}

