## 1.
play_tennis <- read.csv('play_tennis.csv', stringsAsFactors = TRUE)
# Save as .rda file in the 'data' directory of your project
save(play_tennis, file = "data/play_tennis.rda")


## 2. 
library(rpart)
library(rpart.plot)

model <- rpart(PlayTennis ~ ., play_tennis,
               control = rpart.control(cp = 0, maxdepth = 4, minsplit = 1,
                                       minbucket = 1))
rpart.plot(model)

model2 <- rpart(PlayTennis ~ ., play_tennis,
               control = rpart.control(cp = 0, maxdepth = 2, minsplit = 1,
                                       minbucket = 1))
rpart.plot(model2)

model3 <- rpart(PlayTennis ~ ., play_tennis,
                control = rpart.control(cp = 0, maxdepth = 8, minsplit = 1,
                                        minbucket = 1))
rpart.plot(model3)


## 3.
num_matrix_from_df <- function(tennis_data){
  as.matrix(as.data.frame(lapply(tennis_data,
                                 function(x) as.integer(x)-1)))}

# We save the whole dataframe as numeric matrix called PT.
PT <- num_matrix_from_df(play_tennis)

# We divide the matrix in two parts: Features and response.
X <- PT[, 1:4]  
y <- PT[, 5]  

##  5. 

fit_decision_stump_R(X,y)

## 7.

library(Rcpp)
setwd('C:/Users/Gabriel/Desktop/MÁSTERS/2º SEMI C/PROGRAMACIÓN AVANZADA/Tennis project/TennisCR/src')
sourceCpp('gini_index.cpp')
gini_indices <- gini_table_Cpp(X,y)
View(gini_indices)


sourceCpp('Decision_stumps_c++_2.cpp')

# Base Input

X <- PT[, 1:4]  
y <- PT[, 5]  
best_split_Cpp(X,y)


# First input (Data without Outlook)

X2 <- PT[, 2:4]  
best_split_Cpp(X2,y)

# In this case we have 3 features: Temperature, Humidity, and Wind. 
# The result matches the right solution. 
# Without Outlook, Humidity (feature nº 2) 
# has the lowest Gini taking as reference High (category 0)

#2, 0, 0.4074074

# Second Input (Data without Outlook and Humidity)

X3 <- PT[, c(2,4)] 
best_split_Cpp(X3,y)

# In this case we have 2 features: Temperature and Wind. 
# The result matches the right solution. 

# 1, 1, 0.44

# Third input

# In this case, all the feature values are the same, making it impossible to split the data meaningfully.

X4 <- matrix(rep(1, 8), ncol = 1)
y2 <- c(1, 0, 1, 0, 1, 0, 1, 0)


best_split_Cpp(X4, y2)


# The obtained result is the expected. The index has remained in -1 (it was initialized like this)


## 8.

library(microbenchmark)
library(rpart)
results <- microbenchmark(
  Cpp_Version = best_split_Cpp(X, y),
  R_Version = best_split_R(X, y),
  rpart_Version = rpart(PlayTennis ~., data = play_tennis, method = "class", control = rpart.control(maxdepth = 2)),
  times = 1000
)
results

# We plot the results
boxplot(results, main = "Benchmark: C++ vs R vs rpart", ylab = "Time (nanoseconds)")
